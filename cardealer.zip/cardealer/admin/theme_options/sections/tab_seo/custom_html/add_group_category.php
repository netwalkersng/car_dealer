<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div class="tmk_row">
    <br />
	<label class="sel">
		<?php echo $select ?>
	</label>
	<a class="remove-button remove_seo_group_category" href="#"></a>
</div>
