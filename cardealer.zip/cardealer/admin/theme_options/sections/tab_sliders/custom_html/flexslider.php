<?php if ( !defined('ABSPATH') ) exit;

echo TMM_Ext_Sliders::draw_sliders_options();