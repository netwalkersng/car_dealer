<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<aside id="sidebar" class="col-md-3">
    <?php function_exists('dynamic_sidebar') AND dynamic_sidebar('thememakers_single_user_cars') ?>
</aside>	


